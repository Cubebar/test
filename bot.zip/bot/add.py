from linepy import *
import time, random

pwd = "Aa+123456"

cl = LINEV2("jxf76422@fosiq.com",pwd, app="CHROMEOS",version="3",useThrift=True)
kz = LINEV2("aqu06036@romog.com",pwd, app="CHROMEOS",version="3",useThrift=True)
kx = LINEV2("pyo12114@romog.com",pwd, app="CHROMEOS",version="3",useThrift=True)
kc = LINEV2("zou54242@fosiq.com",pwd, app="CHROMEOS",version="3",useThrift=True)
kv = LINEV2("kinik47227@felibg.com",pwd, app="CHROMEOS",version="3",useThrift=True)

bots = [kz.profile.mid,kx.profile.mid,kc.profile.mid,kv.profile.mid]
for b in bots:
   time.sleep(random.choice([1,2,0.5,0.2]))
   cl.addFriendByMid(b)
cl.log("[ cl ] แอดเรียบร้อยแล้ว")

botsz = [cl.profile.mid,kx.profile.mid,kc.profile.mid,kv.profile.mid]
for bb in botsz:
   time.sleep(random.choice([1,2,0.5,0.2]))
   kz.addFriendByMid(bb)
cl.log("[ kz ] แอดเรียบร้อยแล้ว")

botsx = [cl.profile.mid,kz.profile.mid,kc.profile.mid,kv.profile.mid]
for bbb in botsx:
   time.sleep(random.choice([1,2,0.5,0.2]))
   kx.addFriendByMid(bbb)
cl.log("[ kx ] แอดเรียบร้อยแล้ว")

botsc = [cl.profile.mid,kz.profile.mid,kx.profile.mid,kv.profile.mid]
for bbbb in botsc:
   time.sleep(random.choice([1,2,0.5,0.2]))
   kc.addFriendByMid(bbbb)
cl.log("[ kc ] แอดเรียบร้อยแล้ว")

botsv = [cl.profile.mid,kz.profile.mid,kx.profile.mid,kc.profile.mid]
for bbbbb in botsv:
   time.sleep(random.choice([1,2,0.5,0.2]))
   kv.addFriendByMid(bbbbb)
cl.log("[ kv ] แอดเรียบร้อยแล้ว")