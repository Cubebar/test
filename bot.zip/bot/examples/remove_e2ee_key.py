# -*- coding: utf-8 -*- 
from CHRLINE import *
TOKEN="FCNq23ohYXHVjvDMbkec.C1WCPi0iqPPMliqteuWO3a.fSbfUDsIEdKoJjNVyPVRy+JS1Z9gVMKXBXMFoif8Pyw="
cl = CHRLINE(TOKEN, device="IOSIPAD")

pks = cl.getE2EEPublicKeys()
for pk in pks:
    print(f"try remove key id: {pk[2]}")
    cl.removeE2EEPublicKey(pk[1], pk[2], pk[4])