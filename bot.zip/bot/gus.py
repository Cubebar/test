from linepy import *
import time, os, sys
import random
import threading
pwd = "Aa+123456"
#----------------------------------- [ LOGIN BOT ] -----------------------------------
cl = LINEV2("jxf76422@fosiq.com",pwd, app="DESKTOPWIN",useThrift=True)
kz = LINEV2("aqu06036@romog.com",pwd, app="DESKTOPWIN",useThrift=True)
kx = LINEV2("pyo12114@romog.com",pwd, app="DESKTOPWIN",useThrift=True)
kc = LINEV2("zou54242@fosiq.com",pwd, app="DESKTOPWIN",useThrift=True)
kv = LINEV2("kinik47227@felibg.com",pwd, app="DESKTOPWIN",useThrift=True)

#----------------------------------- [ SETTING BOT ] -----------------------------------
kicker = [cl,kz,kx,kc,kv]
#kicker = [cl]
prv_msgs = []
botMids = []
for b in kicker:
   botMids.append(b.profile.mid)
  
protectinvite = []
protectqr = []
protectkick = []
blackList = []
owner = ["u01ade949039cdc72df549ca428d97f1b", "u469d8561d7c1dfea95ab45cecf02465b"]
admin = {}

#----------------------------------- [ BAN&ADMIN ] -----------------------------------
def protect_Bots(op, self):
   try:
      random.choice(kicker).deleteOtherFromChat(op.param1,[op.param2])
      random.choice(kicker).inviteIntoChat(op.param1, op.param3)
      self.acceptChatInvitation(op.param1)
   except Exception as e:
        print(e)
   if op.param2 not in blackList:
       blackList.append(op.param2)

def protect_kick(op):
   try:
      random.choice(kicker).deleteOtherFromChat(op.param1,[op.param2])
   except Exception as e:
        print(e)
   if op.param2 not in blackList:
       blackList.append(op.param2)

def protect_qr(op):
   try:
      if cl.getChats([op.param1]).chats[0].extra.groupExtra.preventedJoinByTicket == False:
          random.choice(kicker).deleteOtherFromChat(op.param1,[op.param2])
          random.choice(kicker).updateChatPreventedUrl(op.param1, True)
   except Exception as e:
        print(e)
   if op.param2 not in blackList:
       blackList.append(op.param2)

def protect_invite(op):
   try:
      random.choice(kicker).deleteOtherFromChat(op.param1,[op.param2])
   except Exception as e:
       print(e)
   if op.param2 not in blackList:
       blackList.append(op.param2)

helpmessage = """「 Help bot protect 」
-> go [@] (เตะ)
-> bye (ให้บอทออกกลุ่ม)

-> adminadd [@] (เพิ่มแอดกลุ่มนี้)
-> admindel [@] (ลบแอดกลุ่มนี้)
-> listadmin (ดูรายชื่อแอดกลุ่ม)

-> banadd [@] (เพิ่มบัญชีดำ)
-> bandel [@] (ลบบัญชีดำ)
-> listban (ดูรายชื่อบัญชีดำ)

-> set (เช็คการตั้งค่า)
-> prokick [on/off] (กันลบ)
-> proinvite [on/off] (กันเชิญ)
-> proqr [on/off] (กันลิ้ง)
-> proall [on/off] (กันทั้งหมด)
"""
#----------------------------------- [ CMDBOTS ] -----------------------------------
def bots(op,cl):
    print(f"\n\n{op}")
    if op.type == 2:pass
    elif op.type == 25:pass
    elif op.type == 26:
        msg = op.message
        if msg.to not in admin:
           admin[msg.to] = {}
        admin[msg.to]["u01ade949039cdc72df549ca428d97f1b"] =True
        msgMetadata = msg.contentMetadata
        if msg.toType == 0:cl.sendChatChecked(msg._from, msg.id)
        elif msg.toType == 1:pass
        elif msg.toType == 2 and msg._from in owner:
            if msg.id not in prv_msgs: prv_msgs.append(msg.id)
            else: return
            if msg.contentType == 0:
                textx = msg.text
                if msg.chunks:
                    textx = cl.decryptE2EETextMessage(msg)
                text = str(textx).lower()
                
                if text == "help" or text == 'คำสั่ง':
                   random.choice(kicker).sendMessageE2EE(msg.to, f"{cl.AtoZ(helpmessage)}")
                elif text == "mid" or text == '//':
                   random.choice(kicker).sendMessageE2EE(msg.to, f"{msg._from}")
                elif text == "rebot":
                   random.choice(kicker).sendMessageE2EE(msg.to,"กำลังรีเซ็ตบอทใหม่..")
                   os.execl(sys.executable,sys.executable,*sys.argv)
                elif text == 'join' or text == 'goto':
#                   cl.updateChatPreventedUrl(msg.to, False)
                   Ticket = cl.reissueChatTicket(msg.to).ticketId
                   for ki in [kz,kx,kc,kv]:
                       ki.acceptChatInvitationByTicket(msg.to, Ticket)
#                   random.choice(kicker).sendMessageE2EE(msg.to, "บอทเข้ามาครบแล้ว (อย่าลืมปิดลิ้งกลุ่ม)")
                elif text == 'out' or text == "bye":
                   for ki in kicker:
                      ki.deleteSelfFromChat(msg.to)

                elif text.startswith("banadd "):
                   Meta = eval(msgMetadata["MENTION"])["MENTIONEES"]
                   sets="เพิ่มคนนี้เข้าบัญชีดำแล้ว"
                   n=1
                   for uid in range(len(Meta)):
                      blackList.append(cl.getContact(Meta[uid]["M"]).mid)
                      sets+=f'\n{n}. {cl.getContact(Meta[uid]["M"]).displayName}'
                      n=n+1
                   random.choice(kicker).sendMessageE2EE(msg.to, sets)
                elif text.startswith("bandel "):
                   Meta = eval(msgMetadata["MENTION"])["MENTIONEES"]
                   sets="ลบคนนี้ออกบัญชีดำแล้ว"
                   n=1
                   for uid in range(len(Meta)):
                      blackList.remove(cl.getContact(Meta[uid]["M"]).mid)
                      sets+=f'\n{n}. {cl.getContact(Meta[uid]["M"]).displayName}'
                      n=n+1
                   random.choice(kicker).sendMessageE2EE(msg.to, sets)
                elif text == 'listban':
                    aa = 1
                    sets="รายชื่อบัญชีดำ: "
                    for mi_d in blackList:
                       sets+=f"\n- {aa}. {cl.getContact(mi_d).displayName}"
                       aa = aa + 1
                    if blackList == []:
                        sets += "\n- ไม่มีคนติดดำ"
                    random.choice(kicker).sendMessageE2EE(msg.to, str(sets))

                elif text.startswith("adminadd "):
                   Meta = eval(msgMetadata["MENTION"])["MENTIONEES"]
                   sets="เพิ่มคนนี้เป็นแอดมินของกลุ่มนี้แล้ว"
                   n=1
                   for uid in range(len(Meta)):
                      admin[msg.to][Meta[uid]['M']] = True
                      sets+=f'\n{n}. {cl.getContact(Meta[uid]["M"]).displayName}'
                      n=n+1
                   random.choice(kicker).sendMessageE2EE(msg.to, sets)
                elif text.startswith("admindel "):
                   Meta = eval(msgMetadata["MENTION"])["MENTIONEES"]
                   sets="ลบคนนี้ออกจากแอดมินของกลุ่มนี้แล้ว"
                   n=1
                   for uid in range(len(Meta)):
                      del admin[msg.to][Meta[uid]["M"]]
                      sets+=f'\n{n}. {cl.getContact(Meta[uid]["M"]).displayName}'
                      n=n+1
                   random.choice(kicker).sendMessageE2EE(msg.to, sets)
                elif text == 'listadmin':
                    aa = 1
                    sets=f"รายชื่อแอดมิน: \nกลุ่ม: {cl.getChats([msg.to]).chats[0].chatName}"
                    for mi_d in admin[msg.to]:
                       sets+=f"\n- {aa}. {cl.getContact(mi_d).displayName}"
                       aa = aa + 1
                    if admin[msg.to] == {}:
                        sets += "\n- ไม่มีแอดมินในกลุ่มนี้"
                    random.choice(kicker).sendMessageE2EE(msg.to, str(sets))

                elif text.startswith("mid "):
                   Meta = eval(msgMetadata["MENTION"])["MENTIONEES"]
                   for uid in range(len(Meta)):
                      middd = threading.Thread(target=random.choice(kicker).sendMessageE2EE, args=(msg.to, Meta[uid]["M"]))
                      middd.start()
                elif text.startswith("go "):
                   Meta = eval(msgMetadata["MENTION"])["MENTIONEES"]
                   for uid in range(len(Meta)):
                      kkk = threading.Thread(target=random.choice(kicker).deleteOtherFromChat, args=(msg.to,[Meta[uid]["M"]]))
                      kkk.start()

                elif text =='set' or text == "ป้องกัน":
                   sets="「 sᴇᴛᴛɪɴɢ ᴘʀᴏᴛᴇᴄᴛ 」"
                   sets+=f"\nɢʀᴏᴜᴘ: {cl.getChats([msg.to]).chats[0].chatName}"
                   if msg.to in protectkick: sets+="\n[⭕] ᴘʀᴏᴛᴇᴄᴛᴋɪᴄᴋ"
                   else:sets+="\n[❌] ᴘʀᴏᴛᴇᴄᴛᴋɪᴄᴋ"
                   if msg.to in protectinvite: sets+="\n[⭕] ᴘʀᴏᴛᴇᴄᴛɪɴᴠɪᴛᴇ"
                   else:sets+="\n[❌] ᴘʀᴏᴛᴇᴄᴛɪɴᴠɪᴛᴇ"
                   if msg.to in protectqr: sets+="\n[⭕] ᴘʀᴏᴛᴇᴄᴛǫʀ"
                   else:sets+="\n[❌] ᴘʀᴏᴛᴇᴄᴛǫʀ"
                   sets+=f"\nɴᴜᴍʙᴇʀ ᴏғ ᴀᴅᴍɪɴs ɪɴ ᴛʜɪs ɢʀᴏᴜᴘ [ {len(admin[msg.to])} ]"
                   cl.sendMessageE2EE(msg.to, sets)

                elif 'prokick ' in text:
                   texts = text.replace('prokick ','')
                   if texts == 'on':
                      if msg.to in protectkick:
                         msgs = cl.AtoZ("Protect Kick sudah aktif")
                      else:
                         protectkick.append(msg.to)
                         msgs = cl.AtoZ("Status : [ ON ]\nDi Group : ")+str(cl.getChats([msg.to]).chats[0].chatMid)
                      random.choice(kicker).sendMessageE2EE(msg.to, cl.AtoZ("「 Status Protect kick 」\n") + msgs)
                   elif texts == "off":
                      if msg.to in protectkick:
                         protectkick.remove(msg.to)
                         msgs = cl.AtoZ("Status : [ OFF ]\nDi Group : ")+str(cl.getChats([msg.to]).chats[0].chatMid)
                      else:
                         msgs = cl.AtoZ("Protect Kick sudah tidak aktif")
                      random.choice(kicker).sendMessageE2EE(msg.to, cl.AtoZ("「 Status Protect kick 」\n") + msgs)
                elif 'proqr ' in text:
                   texts = text.replace('proqr ','')
                   if texts == 'on':
                      if msg.to in protectqr:
                         msgs = cl.AtoZ("Protect Qr sudah aktif")
                      else:
                         protectqr.append(msg.to)
                         msgs = cl.AtoZ("Status : [ ON ]\nDi Group : ")+str(cl.getChats([msg.to]).chats[0].chatMid)
                      random.choice(kicker).sendMessageE2EE(msg.to, cl.AtoZ("「 Status Protect qr 」\n") + msgs)
                   elif texts == "off":
                      if msg.to in protectqr:
                         protectqr.remove(msg.to)
                         msgs = cl.AtoZ("Status : [ OFF ]\nDi Group : ")+str(cl.getChats([msg.to]).chats[0].chatMid)
                      else:
                         msgs = cl.AtoZ("Protect qr sudah tidak aktif")
                      random.choice(kicker).sendMessageE2EE(msg.to, cl.AtoZ("「 Status Protect qr 」\n") + msgs)
                elif 'proinvite ' in text:
                   texts = text.replace('proinvite ','')
                   if texts == 'on':
                      if msg.to in protectinvite:
                         msgs = cl.AtoZ("Protect invite sudah aktif")
                      else:
                         protectinvite.append(msg.to)
                         msgs = cl.AtoZ("Status : [ ON ]\nDi Group : ")+str(cl.getChats([msg.to]).chats[0].chatMid)
                      random.choice(kicker).sendMessageE2EE(msg.to, cl.AtoZ("「 Status Protect invite 」\n") + msgs)
                   elif texts == "off":
                      if msg.to in protectinvite:
                         protectinvite.remove(msg.to)
                         msgs = cl.AtoZ("Status : [ OFF ]\nDi Group : ")+str(cl.getChats([msg.to]).chats[0].chatMid)
                      else:
                         msgs = cl.AtoZ("protect invite sudah tidak aktif")
                      random.choice(kicker).sendMessageE2EE(msg.to, cl.AtoZ("「 Status Protect invite 」\n") + msgs)
                elif 'proall ' in text:
                   texts = text.replace('proall ','')
                   if texts == 'on':
                      if msg.to in protectqr and msg.to in protectinvite and msg.to in protectkick:
                         msgs = cl.AtoZ("Protect all sudah aktif")
                      else:
                         protectqr.append(msg.to)
                         protectinvite.append(msg.to)
                         protectkick.append(msg.to)
                         msgs = cl.AtoZ("Status : [ ON ]\nDi Group : ")+str(cl.getChats([msg.to]).chats[0].chatMid)
                      random.choice(kicker).sendMessageE2EE(msg.to, cl.AtoZ("「 Status Protect all 」\n") + msgs)
                   elif texts == "off":
                      if msg.to in protectqr and msg.to in protectinvite and msg.to in protectkick:
                         protectqr.remove(msg.to)
                         protectinvite.remove(msg.to)
                         protectkick.remove(msg.to)
                         msgs = cl.AtoZ("Status : [ OFF ]\nDi Group : ")+str(cl.getChats([msg.to]).chats[0].chatMid)
                      else:
                         msgs = cl.AtoZ("Protect all sudah tidak aktif")
                      random.choice(kicker).sendMessageE2EE(msg.to, cl.AtoZ("「 Status Protect all 」\n") + msgs)



#----------------------------------- [ OP.TYPE&RUN.BOT] -----------------------------------
    elif op.type == 55:
      if op.param2 in blackList:
         if op.param2 not in botMids+owner:
            ban = threading.Thread(target=random.choice(kicker).deleteOtherFromChat, args=(op.param1, [op.param2]))
            ban.start()
    elif op.type == 122:
       if op.param3 == "4":
         if op.param1 in protectqr:
            if op.param2 not in botMids+owner:
               pqr = threading.Thread(target=protect_qr, args=(op,))
               pqr.start()
    elif op.type == 124:
        if cl.profile.mid in op.param3:
          cl.acceptChatInvitation(op.param1)
    elif op.type == 130:
       if op.param1 in protectinvite:
           if op.param2 not in botMids+owner:
               inv1 = threading.Thread(target=protect_invite, args=(op,))
               inv1.start()
    elif op.type == 133:
       if op.param1 in protectkick:
          if op.param2 not in botMids+owner:
              kks = threading.Thread(target=protect_kick, args=(op,))
              kks.start()
    elif op.type == 133:
       if op.param3 in owner:
          if op.param2 not in botMids+owner:
              oo = threading.Thread(target=random.choice(kicker).deleteOtherFromChat, args=(op.param1, [op.param2]))
              oo.start()
    elif op.type == 133:
       if op.param3 in cl.profile.mid:
          if op.param2 not in botMids+owner:
              t1 = threading.Thread(target=protect_Bots, args=(op,cl))
              t1.start()
#              cl.acceptChatInvitation(op.param1)
    elif op.type == 133:
       if op.param3 in kz.profile.mid:
          if op.param2 not in botMids+owner:
              t2 = threading.Thread(target=protect_Bots, args=(op,kz))
              t2.start()
#              kz.acceptChatInvitation(op.param1)
    elif op.type == 133:
       if op.param3 in kx.profile.mid:
          if op.param2 not in botMids+owner:
              t3 = threading.Thread(target=protect_Bots, args=(op,))
              t3.start()
#              kx.acceptChatInvitation(op.param1)
    elif op.type == 133:
       if op.param3 in kc.profile.mid:
          if op.param2 not in botMids+owner:
              t4 = threading.Thread(target=protect_Bots, args=(op,kc))
              t4.start()
#              kc.acceptChatInvitation(op.param1)
    elif op.type == 133:
       if op.param3 in kv.profile.mid:
          if op.param2 not in botMids+owner:
              t5 = threading.Thread(target=protect_Bots, args=(op,kv))
              t5.start()
#              kv.acceptChatInvitation(op.param1)
             
cl.trace(bots)