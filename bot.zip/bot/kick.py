
#app="CHROMEOS",version="3",useThrift=True)
kicker = []
from linepy import *
import time
import threading
import random
import re

pwd = "="

cl = LINEV2("zataoza1011@gmail.com",
"12345zaQ.", app="DESKTOPWIN",useThrift=True)
kicker.append(cl)

#kz = LINEV2("MAILL",
#pwd,app="DESKTOPWIN",useThrift=True)
#kicker.append(kz)
#kx = LINEV2("MAILL",
#pwd,app="DESKTOPWIN",useThrift=True)
#kicker.append(kx)

saveMid = []
saveUid = []
saveGid = {}
botsMid = []

for _b in kicker:
  botsMid.append(_b.profile.mid)

def kick_userid(gid):
   try:
      cl.deleteOtherFromChat(gid, [saveUid])
   except Exception as ee:
       print(ee)

def bots(op,cl):
    print(f"\n\n{op}")
    if op.type == 2:pass
    elif op.type == 25:pass
    elif op.type == 26:
        msg = op.message
        msgMetadata = msg.contentMetadata
        if msg.toType == 0:cl.sendChatChecked(msg._from, msg.id)
        elif msg.toType == 1:pass
        elif msg.toType == 2:
            if msg.contentType == 0:
                textx = msg.text
                if msg.chunks:
                    textx = cl.decryptE2EETextMessage(msg)
                text = str(textx).lower()

                if text == "กลุ่ม" or text == "group":
                  lists="รายชื่อกลุ่มของคุณ :"
                  no=1
                  for gid in cl.getAllChatMids().memberChatMids:
                     lists+=f"\n{no}. {cl.getChats([gid]).chats[0].chatName} \n ลิ้งกลุ่ม : {'เปิด' if cl.getChats([gid]).chats[0].extra.groupExtra.preventedJoinByTicket == False else 'ปิด'} / สมาชิก [{len(cl.getChats([gid]).chats[0].extra.groupExtra.memberMids)}] คน人"
                     no=no+1
                  cl.sendMessageE2EE(msg.to, lists)
         
                elif text.startswith("เชฟกลุ่ม"):
                  _gd = list(cl.getAllChatMids().memberChatMids)
                  _mids = _gd[int(text.split(" ")[1])-1]
                  _chat = cl.getChats([_mids]).chats[0].extra.groupExtra.memberMids
                  for mid_s in _chat:
                     saveMid.append(mid_s)
                  saveGid[_mids] = True
                  cl.sendMessageE2EE(msg.to, f"บันทึกรายชื่อกลุ่ม {cl.getChats([_mids]).chats[0].chatName} เรียบร้อย!!")
                  
                elif text == 'เช็คชื่อ':
                  tagst = "รายชื่อคนในห้อง :"
                  no=1
                  if saveMid == []:
                     cl.sendMessageE2EE(msg.to,"ยังไม่ได้เพิ่มกลุ่ม ^¢^")
                  else:
                     for id in saveMid:
                       tagst+=f"\n{no}. {cl.getContact(id).displayName}"
                       no=no+1
                     cl.sendMessageE2EE(msg.to, str(tagst))

                elif text.startswith("เชฟลบ"):
                  _n = text.replace(text.split(" ")[0] + " ","").split(";")
                  _gd = list(saveMid)
                  for i in range(len(_n)):
                     _mids = _gd[int(_n[i])-1]
                     saveUid.append(_mids)
                  cl.sendMessageE2EE(msg.to,"มี [{len(_mids)}] คน人\nบันทึกเรียบร้อย >_<!")
                  
                elif text == "เช็คลบ":
                  if saveUid == []:
                     cl.sendMessageE2EE(msg.to, "None")
                  else:
                     texts="รายชื่อที่จะลบ :"
                     for uid in saveUid:
                         texts+=f"\n- {cl.getContact(uid).displayName} \nMID : {cl.getContact(uid).mid}"
                     cl.sendMessageE2EE(msg.to, str(texts))
                     
                elif text == "ลุย":
                  if saveUid == []:
                     cl.sendMessageE2EE(msg.to, "ยังไม่ได้เพิ่มคนที่จะลบ ^¢^")
                  else:
                     t2=threading.Thread(target=kick_userid,args=(saveGid,))
                     t2.start()

                elif text == "re":
                   saveMid.clear()
                   saveUid.clear()
                   saveGid={}
                   cl.sendMessageE2EE(msg.to, "ตั้งค่าใหม่ได้เลย-¢-")

                elif text.startswith("มุด"):
                   _text = text.split(" ")[1]
                   if '/ti/g/' in _text:
                      _url = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?').findall(msg.text)
                      for keyqr in _url:
                         try:
                            gids = cl.findChatByTicket(keyqr).chat.chatMid
                            cl.acceptChatInvitationByTicket(gids, keyqr)
                         except Exception as ee:
                             print(ee)
                      cl.sendMessageE2EE(msg.to, "เข้ากลุ่มแล้ว")
    elif op.type == 124:
       if op.param1 == cl.profile.mid:
           cl.acceptChatInvitation(op.param1)
    elif op.type == 127:
        if op.param1 in cl.groups:
           cl.groups.remove(op.param1)
    elif op.type == 129:
        if op.param1 not in cl.groups:
           cl.groups.append(op.param1)
    elif op.type == 133:
        if op.param1 in cl.groups:
           cl.groups.remove(op.param1)

cl.trace(bots)                   