
from linepy import *
import asyncio
group = input("ID Group : ")
mid_ = []
num = int(input("กำหนดลบเท่าไร : "))
for i in range(0, num):
   _uid = input("MID : ")
   mid_.append(_uid)
   print(f"{mid_}")

cl = LINEV2(
"zataoza1011@gmail.com",
"12345zaQ.",
app="DESKTOPWIN",useThrift=True)

to = group

async def kickMids(gid, mid):
    cl.deleteOtherFromChat(gid, mid)
    return ""
if __name__ == '__main__':
    asyncio.run(kickMids(to, mid_))
    print('DONE.')