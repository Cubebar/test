from linepy import *
from pyfiglet import figlet_format

cl = LINEV2("zataoza1011@gmail.com",
"12345zaQ.", app="DESKTOPWIN",useThrift=True)
list_Mids = []
print(f'{figlet_format("LOGIN - BOTS")}')
num=1
for b in cl.getAllChatMids().memberChatMids:
   print(f'{num}. {cl.getChats([b]).chats[0].chatName}')
   num=num+1
print("\n\nกรุณาใส่ตัวเลขตามรายชื่อกลุ่มที่ต้องการแอด (*¢*)")
chat = input("ตัวเลขกลุ่ม : ")
_gd = list(cl.getAllChatMids().memberChatMids)
_mids = _gd[int(chat)-1]
print(f"""ข้อมูลกลุ่มที่คุณเลือก:

-> ชื่อกลุ่ม: {cl.getChats([_mids]).chats[0].chatName}
-> เจ้าของกลุ่ม: {cl.getContact(cl.getChats([_mids]).chats[0].extra.groupExtra.creator).displayName}
-> สมาชิก [{len(cl.getChats([_mids]).chats[0].extra.groupExtra.memberMids)}] คน
-> GID: {cl.getChats([_mids]).chats[0].chatMid}

""")
a = 1
for _ids in cl.getChats([_mids]).chats[0].extra.groupExtra.memberMids:
  print(f"{a}.{cl.getContact(_ids).displayName} / [{cl.getContact(_ids).mid}]")
  a = a+1