from linepy import *
import time
import threading


cl = LINEV2("taozapao1@gmail.com", "12345zaQ.", app="CHROMEOS",version="3")


def sendFlex(to, cover, pict, name, bio, url):
   data={'type':'flex','altText':"profile",'contents':{
"type":"carousel","contents":[
{"type":"bubble","styles":{"body":{"backgroundColor":"#708090"},"footer":{"backgroundColor":"#708090"}},
"hero": {"type":"image","url": cover,"size":"full","aspectRatio":"20:13","aspectMode":"cover"},
"body":{"type":"box","layout":"vertical","contents":[{"type":"image","url":pict,"size":"lg"},
{"type":"box","layout":"vertical","margin":"sm","spacing":"sm","contents":[
{"type":"box","layout":"baseline","spacing":"sm","contents":[{"type":"text","text":name,"color":"#FFFFFF","wrap":True,"size":"lg","gravity":"center","weight": "bold","align": "center"}]},
{"type":"box","layout":"baseline","spacing":"sm","contents":[{"type":"text","text":bio,"color":"#FFFFFF","wrap":True,"size":"md","gravity":"center","weight": "regular","align": "center"}]},
]}]},
"footer":{"type":"box","layout":"vertical","spacing":"sm","contents":[{"type":"button","style":"primary","color":"#ff3333","action":{"type":"uri","label":"ติดต่อ","uri":url}},{"type":"spacer","size":"sm"}],"flex":0}}]}}
   cl.sendLiff(to, data)

def sendFlexV2(to, text, user):
   data={'type':'flex','altText':"profile",'contents':{
  "type": "carousel",
  "contents": [{
      "type":"bubble",
      "body": {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "image",
            "url":'https://cdn.icon-icons.com/icons2/901/PNG/512/youtube_icon-icons.com_69260.png',
            "size": "md"
          },
          {
            "type": "text",
            "text": text,
            "wrap": True
          }
        ]
      },
      "footer": {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "button",
            "style": "primary",
            "action": {
              "type": "uri",
              "label": "Go",
              "uri": f"line://nv/profilePopup/mid={user}"
            }
          }
        ]
      }
    },
    {
      "type": "bubble",
      "body": {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "text",
            "text": text,
            "wrap": True
          }
        ]
      },
      "footer": {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "button",
            "style": "primary",
            "action": {
              "type": "uri",
              "label": "Go",
              "uri": f"line://nv/profilePopup/mid={user}"
            }
          }
        ]
      }
    }
  ]}
}
   cl.sendLiff(to, data)

def bots(op,cl):
    print(f"\n\n{op}")
    if op.type == 2:pass
    elif op.type == 25:pass
    elif op.type == 26:
        msg = op.message
        msgMetadata = msg.contentMetadata
        if msg.toType == 0:cl.sendChatChecked(msg._from, msg.id)
        elif msg.toType == 1:pass
        elif msg.toType == 2:
            if msg.contentType == 0:
                textx = msg.text
                if msg.chunks:
                    textx = cl.decryptE2EETextMessage(msg)
                to=msg.to
                text = str(textx).lower()
                if text == "/":
                  sendFlexV2(msg.to,"TEST FLEX MESSAGE \nTEST\nTEST\nTEST!", msg._from)
                if text == "hi":
                   cl.sendMessageE2EE(msg.to,"Hello for you :/")
                if text == "//":
                   p='https://cdn.icon-icons.com/icons2/901/PNG/512/youtube_icon-icons.com_69260.png'
                   sendFlex(msg.to, p, p,"TEST!", "Flex Message",f"line://nv/profilePopup/mid={cl.profile.mid}")
                   
cl.trace(bots)